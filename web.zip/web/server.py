import subprocess
from flask import Flask, request, render_template

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        #g++ cnc.cpp util/* lex/* -std=c++11 -Wall -Wextra
        preoutput = subprocess.check_output('g++ cnc.cpp util/* lex/* -std=c++11 -Wall -Wextra', shell=True)
        print(preoutput)
        code = request.form['code']
        with open('code.cn', 'w') as file:
            file.write(code)
        output = subprocess.run(['./a.out', 'code.cn', 'code.cpp'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        result23 = subprocess.run(['cat', 'code.cpp'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        output2 = subprocess.run(['g++', '-std=c++11', 'code.cpp'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if output.returncode == 0:
            result = subprocess.run(['./a.out'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            return render_template('index.html', result=result.stdout.decode(), result2=result23.stdout.decode())
        else:
            render_template('index.html', result2=result23.stdout.decode())
            return render_template('index.html', result=result.stdout.decode(), result2=result23.stdout.decode())

    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)